﻿/// <reference path="../../Scripts/angular.js" />

(function (angular) {
    "use strict";
    var app = angular.module("myApp", ["countryData", "directorData", "movieData"]);

    app.filter("directorName", function (directors) {
        return function (directorId) {
            var director = directors.filter(function (d) {
                return d.id === directorId;
            });

            if (director.length) {
                return director[0].name;
            }
            return "";
        };
    });


    app.controller("MoviesCtrl", ["$scope", "countries","directors","movies",
        function ($scope, countries, directors, movies) {
            $scope.movies = movies;
            $scope.directors = directors;
            $scope.countries = countries;

            $scope.sortOrder = "year";
            
            $scope.selectedMovie = null;

            $scope.select = function (movie) {
                $scope.selectedMovie = movie;
            };

            $scope.save = function () {
                $scope.selectedMovie = null;
            };
        }
    ]);

}(angular));
